import { useState } from 'react';

import Box from '@mui/material/Box';
import Drawer from '@mui/material/Drawer';
import IconButton from '@mui/material/IconButton';
import AppBar from '@mui/material/AppBar';
import Toolbar from '@mui/material/Toolbar';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemButton from '@mui/material/ListItemButton';
import ListItemText from '@mui/material/ListItemText';
import ListItemIcon from '@mui/material/ListItemIcon';

import MenuIcon from '@mui/icons-material/Menu';
import AssignmentIcon from '@mui/icons-material/Assignment';
import RestaurantIcon from '@mui/icons-material/Restaurant';
import HomeIcon from '@mui/icons-material/Home';

import { Link, Outlet } from 'react-router';

function DrawerMUI() {

  const [open, setOpen] = useState(false);

  const handleOpen = () => {
    setOpen(true);
  }

  const handleClose = () => {
    setOpen(false);
  }

  return (
    <Box>
      <AppBar position='static'>
        <Toolbar><IconButton onClick={() => handleOpen()} color='inherit'><MenuIcon /></IconButton>  </Toolbar>
      </AppBar>

      <Drawer anchor='right' open={open} onClick={() => handleClose()}>
        <List>

          <ListItem disablePadding>
            <ListItemButton component={Link} to='/'> 
              <ListItemIcon><HomeIcon /></ListItemIcon>
              <ListItemText primary='Etusivu' />
            </ListItemButton>
          </ListItem>

          <ListItem disablePadding>
            <ListItemButton component={Link} to='/grid'> 
              <ListItemIcon><AssignmentIcon /></ListItemIcon>
              <ListItemText primary='Tietoja' />
            </ListItemButton>
          </ListItem>

          <ListItem disablePadding>
            <ListItemButton component={Link} to='/lomake'>
              <ListItemIcon><AssignmentIcon /></ListItemIcon>
              <ListItemText primary='Lomake' />
            </ListItemButton>
          </ListItem>

          
          <ListItem disablePadding>
            <ListItemButton component={Link} to='/resepti'>
              <ListItemIcon><RestaurantIcon /></ListItemIcon>
              <ListItemText primary='Resepti' />
            </ListItemButton>
          </ListItem>


        </List>
        
      </Drawer>

      <Outlet />

    </Box>
  );
}

export default DrawerMUI;