import { useState } from "react";
import {
  Button,
  TextField,
  Box,
  Slider,
  Switch,
  Typography,
} from "@mui/material";

function LomakeMUI() {
  const [nimi, setNimi] = useState("");
  const [arvosana, setArvosana] = useState(0);
  const [suosittele, setSuosittele] = useState(false);

  return (
    <Box sx={{ width: 300, margin: "40px auto" }}>
      <TextField
        label="Nimi"
        fullWidth
        value={nimi}
        onChange={(e) => setNimi(e.target.value)}
      />

      <Typography sx={{ mt: 3 }}>Arvosana</Typography>

      <Slider
        value={arvosana}
        onChange={(e, value) => setArvosana(value)}
        min={0}
        max={5}
        step={1}
        // https://www.youtube.com/watch?v=wfj3QeFViHs hyödynnetty ja löytyy myös switch video:https://www.youtube.com/watch?v=ALoU-CIXqjg
        // + MUI:n omat kalvot
        marks={[
          { value: 0, label: "0" },
          { value: 1, label: "1" },
          { value: 2, label: "2" },
          { value: 3, label: "3" },
          { value: 4, label: "4" },
          { value: 5, label: "5" },
        ]}
        valueLabelDisplay="auto"
      />

      <Typography sx={{ mt: 2 }}>Suosittelen</Typography>
      <Switch
        id="Switch" 
        checked={suosittele}
        onChange={(e) => setSuosittele(e.target.checked)}
      />
      <br />

      {/* Napit - Buttons (Lisäys napissa ei toiminnallisuutta) */}
      <Box display="flex" gap={2}>
        <Button variant="outlined" color="primary">
          Lisaa
        </Button>
      

        <Button variant="outlined" color="secondary" onClick={() => {
          setNimi("");
          setArvosana(0);
          setSuosittele(false);
        }}>
          Tyhjenna
        </Button>
      </Box>
      

    </Box>
  );
}

export default LomakeMUI;
