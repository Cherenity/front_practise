import {
  Box,
  Button,
  Card,
  CardHeader,
  CardContent,
  CardMedia,
  CardActions,
  Typography,
} from "@mui/material";

import CreateIcon from "@mui/icons-material/Create";
import HomeIcon from "@mui/icons-material/Home";

import Grid from "@mui/material/Grid";


function GridMUI({ tiedot }) {
  return (
    <Grid container spacing={4}>
      {tiedot.map((tieto) => {
        return (
          <Grid key={tieto.id} item xs={12} sm={6} md={4} lg={3}>
            <Box
              sx={{
                p: 2,
                border: 4,
                borderRadius: 2,
                backgroundColor: "#f4d5e0",
              }}
            >
              <Card sx={{ maxWidth: 300, backgroundColor: "#d3f6fa" }}>
                <CardHeader title={tieto.otsikko} subheader={tieto.paiva} />

                <CardContent>
                  <CardMedia
                    component="img"
                    image={tieto.picture}
                    sx={{
                      height: 250,
                      border: 3,
                      borderRadius: 4,
                      mb: 2,
                    }}
                  />

                  <Typography>
                    {"Tekstiä voisi lisätä tähän"}
                  </Typography>

                </CardContent>

                <CardActions>
                  <Button
                    variant="contained"
                    startIcon={<HomeIcon />}
                    sx={{ backgroundColor: "black" }}
                  >
                    Etusivulle
                  </Button>

                  <Button
                    variant="outlined"
                    startIcon={<CreateIcon />}
                    sx={{ color: "black", borderColor: "black" }}
                  >
                    Muokkaa
                  </Button>
                </CardActions>

              </Card>

            </Box>   
          </Grid>
        );
      })}
    </Grid>
  );
}

export default GridMUI;
