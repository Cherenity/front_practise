import { useEffect, useState } from "react";

function Resepti() {

  const [viesti, setViesti] = useState('Haetaan');
  const [ateria, setAteria] = useState([]);

  const fetchUrl = async () => {
    try {
      const response = await fetch('https://www.themealdb.com/api/json/v1/1/filter.php?c=Chicken');
      const json = await response.json();
      setAteria(json.meals);
      setViesti('');

    } catch (error) {
      setViesti('Tietojen haku ei onnistunut.')   
    }
  }

  useEffect(() =>{
    fetchUrl();
  }, []);


  if (viesti.length > 0) {
    return (
      <p>{viesti}</p>
    )
  }

  return (  
    <>  
    {
      ateria.map((meal) => {
        return (
          <p key={meal.idMeal} style={{margin: 0}}>
            {meal.strMeal}
          </p>
        )})
    }
    </>
  );
}

export default Resepti;