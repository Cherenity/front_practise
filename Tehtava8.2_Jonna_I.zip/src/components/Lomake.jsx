import { useState } from 'react';

function Lomake(){

  const [lomake, setLomake] = useState({
    nimi: '',
    paiva: '',
    arvosana: '', 
  });

  const [viesti, setViesti] = useState('');


  const lisaaTiedot = () => {
    // Lisätty trim, niin ei voi laittaa vain tyhjiä välilyöntejä
    if(!lomake.nimi.trim() || !lomake.paiva.trim() || !lomake.arvosana.trim()) {
      setViesti("Kaikissa kentissä pitää olla arvot");
      return;
    }

    setViesti("Talletettiin");
    setLomake({
      nimi: '',
      paiva: '',
      arvosana: '',
    });
  };

  const muuta = (e) => {
    setLomake({
      ...lomake,
      [e.target.name]: e.target.value
    })
    setViesti("")
  };

  return(
    <>
    <form>

      <label>Nimi{" "}
        <input type='text' name='nimi' value={lomake.nimi} onChange={(e) => muuta(e)}
        /><br />
      </label>

      <label>Päivä{" "}
        <input type='text' name='paiva' value={lomake.paiva} onChange={(e) => muuta(e)}
        size="15"/><br />
      </label>

      <label>Arvosana{" "}
        <input type='text' name='arvosana' value={lomake.arvosana}
        onChange={(e) => muuta(e)}
        size="5"/><br />
      </label>
      
      {/* Painike */}
      <input type='button' value='Lisää' onClick={() => lisaaTiedot()} />

    </form>
    <br/>
    {viesti}
    </>
  );
}

export default Lomake;