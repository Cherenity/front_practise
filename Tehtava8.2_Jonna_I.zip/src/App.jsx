

  const data = [
    {
      id: 1,
      otsikko: "Assi",
      paiva: "2026-02-29",
      picture: "kuvia/assi.jpg",
    },
    {
      id: 2,
      otsikko: "Myynti",
      paiva: "2026-03-01",
      picture: "kuvia/myynti.jpg",
    },
    {
      id: 3,
      otsikko: "Tiko",
      paiva: "2026-06-24",
      picture: "kuvia/tiko.jpg",
    },
    {
      id: 4,
      otsikko: "Bite",
      paiva: "2026-05-31",
      picture: "kuvia/yleinen1.jpg",
    },
    {
      id: 5,
      otsikko: "Muu",
      paiva: "2026-02-29",
      picture: "kuvia/yleinen2.jpg",
    },
  ];

import DrawerMUI from "./MUI/DrawerMUI";

import { Stack } from "@mui/material";
import LomakeMUI from "./MUI/LomakeMUI";
import GridMUI from "./MUI/GridMUI";
import Etusivu from "./components/Etusivu";
import { BrowserRouter, Routes, Route } from 'react-router';
import Resepti from "./components/Resepti";

function App() {

  return (
    <>
      <Stack direction="column" spacing={2}>
        {/* Tuli himan kiire tehtävän kanssa, 
        niin hyödynnetty aiempaa 6.2 tehtävää pohjana. */}

        <BrowserRouter>
          <Routes>
            <Route path="/" element={<DrawerMUI />}>
              <Route index element={<Etusivu />} />
              <Route path = '/grid' element={<GridMUI tiedot={data}/>} />
              <Route path = '/lomake' element={<LomakeMUI />} />
              <Route path='/resepti' element={<Resepti />} />
              <Route path='*' element={<h1>Virhe: sivua ei löydy</h1>} />      
            </Route>
          </Routes>
        </BrowserRouter>
    
      </Stack>
    </>
  )
}

export default App
